class NoPieceError < RuntimeError; end
class InvalidMoveError < RuntimeError; end