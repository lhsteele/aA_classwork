require "json"

class Flash
  attr_reader :now

  def initialize(req)
    @flash_cookie = req.cookies["_rails_lite_app_flash"]
    @now = @flash_cookie ? JSON.parse(@flash_cookie) : Hash.new { |hash, k| hash[k] = nil }
    @main_cookie = Hash.new { |hash, k| hash[k] = nil }
  end

  def []=(key, value)
    @main_cookie[key.to_s] = value
  end

  def [](key)
    now[key.to_s] || @main_cookie[key.to_s]
  end

  def store_flash(res)
    res.set_cookie("_rails_lite_app_flash", {
      path: "/",
      value: @main_cookie.to_json,
    })
  end
end
