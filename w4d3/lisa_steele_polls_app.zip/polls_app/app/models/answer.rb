class Answer < ApplicationRecord
end