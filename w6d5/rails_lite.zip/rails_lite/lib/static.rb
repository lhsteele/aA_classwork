class Static
  def initialize(app)
  end

  def call(env)
  end
end
